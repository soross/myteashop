You DO NOT need all the jars in this folder to run XFire. For a quick
guid of which jars you do and do not need please consult:

http://xfire.codehaus.org/Dependency+Guide

Thanks!